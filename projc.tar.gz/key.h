#ifndef KEY_H_   /* Include guard */
#define KEY_H_
extern unsigned char myyykey[16];
extern unsigned char myyykey8[6][16];
extern unsigned short inocmid;
extern struct sockaddr_in pvaddr;
extern struct incmlist *listtt;
extern int pktsent;
#endif
