#ifndef TUNNEL_H_   /* Include guard */
#define TUNNEL_H_
extern int tun_alloc(char *dev, int flags);
extern int in_cksum(u_short *addr, int len);
extern int creatckt_s5();
extern int creatckt_s6();
extern void routerroutine();
extern void router_stage6();
extern void class_AES_set_encrypt_key();
extern void class_AES_set_decrypt_key();
extern void class_AES_encrypt_with_padding();
extern void class_AES_decrypt_with_padding();

struct mycntrlmsg
{
unsigned short circid;
unsigned short portnum;
};
struct mycntrlmsgr
{
unsigned short circid;
};
#endif
