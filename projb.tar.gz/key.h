#ifndef KEY_H_   /* Include guard */
#define KEY_H_
extern unsigned char myyykey[16];
extern struct sockaddr_in pvaddr;
#endif
